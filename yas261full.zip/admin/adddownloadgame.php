<strong class="h">Add Games</strong>
			<div class="box">
			1.Type name of game and game description.<br/><br/>
			2.Select game thumbnail 
			(jpg, gif, png with dimensions of 100x100 pixels).<br/><br/>			
			3.Select Zip file that contains the swf game file,
			text file (containing the description,
			instructions and keywords) and jpg 
			image thumbnail 100x100 pixels.<br/><br/>
			4.Click checkbox only if you wish guests
			or members to receive email.
			</div>