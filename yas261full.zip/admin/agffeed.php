<?php
include ("../includes/db_functions.inc.php");
include ("agf_functions.php");
get_agffeed();
?>