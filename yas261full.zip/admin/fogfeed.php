<?php
include ("../includes/db_functions.inc.php");
get_fgdfeed();
?>