		<div id="right-column">
		<?php include ("right_column.php");?>
	  </div>
	</div>
	<div id="footer"></br>&copy;<a href="http://www.yourarcadescript.com">YourArcadeScript.com</a></br>
	<span><a href="http://www.yourarcadescript.com/forum">Support Forum</a></span><br/>
	</br></div>
</div>
</body>
</html>