<?php include ("left_column/links.php");?>
<?php include ("left_column/games.php");?>
<?php include ("left_column/comments.php");?>
<?php include ("left_column/social.php");?>
<?php include ("left_column/feeds.php");?>