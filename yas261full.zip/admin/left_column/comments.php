<h3>Interaction</h3>
<ul class="nav">
	<li><a href="index.php?act=comments" title="Comments">Comments</a></li>
	<li><a href="index.php?act=memberscomment" title="Members Comments">Members Comments</a></li>
	<li><a href="index.php?act=newsblogcomments" title="News Blog Comments">News Blog Comments</a></li>
	<li><a href="index.php?act=managetopics" title="Manage Topics">Manage Forum Topics</a></li> 
	<li><a href="index.php?act=manageposts" title="Manage Games">Manage Forum Post</a></li>
	<li class="last"><a href="index.php?act=manageforumcats" title="Manage Forum Cats">Manage Forum Cats</a></li>
</ul>