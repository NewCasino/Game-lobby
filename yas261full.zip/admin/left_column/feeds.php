<h3>Feeds</h3>
			<ul class="nav">
      <li><a href="index.php?act=manageagffeed" title="Arcade Game Feed">AGF Game Feed</a></li>
			<li><a href="index.php?act=managemgffeed" title="Install ex-Mochi Games">ex-Mochi Feed Games</a></li>
			<li><a href="index.php?act=managefogfeed" title="FOG Feed">FOG Feed Games</a></li>
			<li><a href="index.php?act=managefgdfeed" title="FGD Feed">FGD Feed Games</a></li>
			<li class="last"><a href="index.php?act=managekong" title="Kongregate Feed">Kongregate Feed Games</a></li>
			</ul>