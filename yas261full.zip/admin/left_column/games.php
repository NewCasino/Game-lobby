<h3>Games</h3>
<ul class="nav">
<li><a href="index.php?act=managegames" title="Manage Games">Manage Games</a></li>
<li><a href="index.php?act=managegamequeue" title="Manage GameQueue">Manage GameQueue</a></li>
<li><a href="index.php?act=uploadgames" title="Upload Games">Upload Games</a></li>
<li><a href="index.php?act=addcode" title="Ad Code">Add Code</a></li>
<li><a href="index.php?act=addmedia" title="Ad Media">Add Media</a></li>
<li><a href="index.php?act=adddownloadgame" title="Add Downloadable Game">Add Downloadable Game</a></li>
<li><a href="index.php?act=managedowngame" title="Manage Downloadable Games">Manage Downloadables</a></li>
<li class="last"><a href="index.php?act=brokenfiles" title="Broken Files">Broken Files</a></li>
</ul>