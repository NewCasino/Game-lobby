<h3>Main</h3>
<ul class="nav">
	<li><a href="index.php?act=general" title="Home">Home</a></li>
	<li><a href="index.php?act=settings" title="Settings">Settings</a></li>
	<li><a href="index.php?act=categories">Categories</a></li>
	<li><a href="index.php?act=links">Links</a></li>
	<li><a href="index.php?act=cache">Clear Cache</a></li>
	<li><a href="index.php?act=managejobs">Scheduled Jobs</a></li>
	<li><a href="index.php?act=managelogs">Manage Logs</a></li>
	<li><a href="index.php?act=ads" title="Manage Ads">Manage Ads</a></li>
	<li><a href="index.php?act=addads" title="Add ads">Add Ads</a></li>
	<li><a href="index.php?act=managedbbackup" title="Backup Database">Backup Database</a></li>
	<li class="last"><a href="index.php?act=logout" title="Logout">Logout</a></li>
</ul>