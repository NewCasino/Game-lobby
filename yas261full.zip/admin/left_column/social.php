<h3>Social</h3>
<ul class="nav">
	<li><a href="index.php?act=socialids" title="Social App IDs for Login">Social App IDs</a></li>
</ul>