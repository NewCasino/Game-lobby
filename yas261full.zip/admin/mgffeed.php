<?php
include ("../includes/db_functions.inc.php");
include ("mgf_functions.php");
get_mgffeed();
?>