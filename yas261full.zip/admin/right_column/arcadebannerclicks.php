<div><h3>Webmaster resources</h3></div><div style="clear:both;"></div><div class="box">
<a href="http://www.arcadebannerclicks.com/index.php?id=175" target="_blank" title="Arcade Banner Clicks"><img src="<?php echo $setting['siteurl'].'admin/img/abcBanner2.png';?>" alt="banner exchange"/></a>
</div>