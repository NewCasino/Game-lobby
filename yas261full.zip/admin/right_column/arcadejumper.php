<div class="box">
<a href="http://arcadejumper.com/" target="_blank" title="Arcade Jumper"><img src="<?php echo $setting['siteurl'].'admin/img/arcadejumpers121.gif';?>" width="121px" alt="Arcade Jumper"/></a>
</div>
<div class="box">
<a href="http://www.bannerflux.com/index.php?id=bigdaddy75" target="_blank" title="BannerFlux"><img src="<?php echo $setting['siteurl'].'admin/img/bannerflux.png';?>" width="121px" alt="Bannerflux"/></a>
</div>