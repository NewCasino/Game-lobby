<strong class="h">Add Code</strong>
			<div class="box">
			Do not forget to create, upload, and add a thumbnail image!
			</div>