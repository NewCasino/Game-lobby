<strong class="h">Uploading</strong>
			<div class="box">
Optional for <b>swf</b>, when uploading, the dimensions are detected. Enter the values if you want to set your own.<br />
Required for <b>dcr</b></div>