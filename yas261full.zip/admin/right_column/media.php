<strong class="h">Add Media</strong>
			<div class="box">
			Height/Width not used for videos.<br/>
	To change the embedded codes, look in the media folder.<br/>
	For youtube videos, enter the address (i.e. <br/>
	http://www.youtube.com/watch?v=aRn5-LQCg2s )
	in the File path.<br/>
	Do not forget to create, upload, and add a thumbnail image!</div>