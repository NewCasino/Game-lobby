<strong class="h">Mod rewrite</strong>
<div class="box">For SEO URLs. If you select yes, your server must support mod rewrite. (most do)</div>