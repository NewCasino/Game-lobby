<strong class="h">Sitemap</strong>
			<div class="box">
			Generate a game sitemap by clicking
			on the link.When sitemap is created
			it will show you link of the
			sitemap.xml file.
			</div>