<OBJECT classid='clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B' width="530"
    height="530" codebase='http://www.apple.com/qtactivex/qtplugin.cab'>
    <param name='src' value="<?php echo $setting['siteurl'].$row['file'];?>">
    <param name='autoplay' value="true">
    <param name='controller' value="true">
    <param name='loop' value="true">
    <EMBED src="<?php echo $setting['siteurl'].$row['file'];?>" width="530" height="530" autoplay="true" controller="true" loop="true" pluginspage='http://www.apple.com/quicktime/download/'>
    </EMBED>
</OBJECT>