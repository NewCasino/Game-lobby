<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://www.adobe.com/go/getflashplayer" width="100%" height="100%" align="middle">
	<param name="movie" value="<?php echo $setting['siteurl'].$row['file'];?>" />
    <param name="quality" value="high" />
    <param name="menu" value="true">
    <embed width="100%" height="100%" src="<?php echo $setting['siteurl'].$row['file'];?>" width="100%" height="100%" align="middle" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
</object>