<?php
$adSchedule = array(2=>"Right Column 120x600",
					4=>"Game Header 468x60",
					7=>"Left Column 160x600",
					8=>"Lightbox Game Page, Home Left Column",
					9=>"Lightbox Game Page, Right Column", 
					10=>"Home Left Column",
					11=>"Google Analytics"
					);
?>