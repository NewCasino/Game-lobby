<?php
$adSchedule = array(2=>"Right Column 160x600",
					4=>"Game Header 468x60",
					7=>"Left Column 160x600",
					8=>"Banner Exchange Lightbox Game Page 100x100",
					9=>"Banner Exchange Lightbox Game Page 100x100", 
					10=>"Banner Exchange Left Column 100x100",
					11=>"Google Analytics"
					);
?>