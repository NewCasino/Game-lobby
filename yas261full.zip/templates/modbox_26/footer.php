<!--<div class="clear"></div>-->
</div>
<!-- end center -->
<?php include 'rightcolumn.php';?>
<!-- begin footer -->
<div id="footer">
<div id="copyright"> 
&copy; 2012<?php if (date("Y") > "2012") echo '-'.date("Y"); ?>&nbsp;<a href="<?php echo $setting['siteurl'];?>"><?php echo $setting['sitename'];?></a><br/>
<?php
  //Don't remove unless you purchased backlink removal
?>
<span style="font-size:10px;">Powered by  </span><a href="http://www.yourarcadescript.com" target="blank"><span style="font-size:10px;">YourArcadeScript <?php echo $setting['version'];?></span></a></span>
</div>
</div>
<!-- end footer -->
</div>
<!-- end content_wrapper -->
</div>
<!--end body_wrapper -->
</body>
</html>